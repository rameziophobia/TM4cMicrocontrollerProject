#ifndef __EZ123G_LIB__H
#define __EZ123G_LIB__H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include "ezDefines.h"
#include "ezTimer.h"
#include "ezLCD.h"

#endif


